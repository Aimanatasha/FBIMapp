angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('menu.dairyGoatBreed', {
    url: '/dairygoatBreed',
    views: {
      'side-menu21': {
        templateUrl: 'templates/dairyGoatBreed.html',
        controller: 'dairyGoatBreedCtrl'
      }
    }
  })

  .state('menu.breedingMethod', {
    url: '/breedingMethod',
    views: {
      'side-menu21': {
        templateUrl: 'templates/breedingMethod.html',
        controller: 'breedingMethodCtrl'
      }
    }
  })

  .state('menu.commonDisease', {
    url: '/commonDisease',
    views: {
      'side-menu21': {
        templateUrl: 'templates/commonDisease.html',
        controller: 'commonDiseaseCtrl'
      }
    }
  })

  .state('menu', {
    url: '/side-menu21',
    templateUrl: 'templates/menu.html',
    controller: 'menuCtrl'
  })

  .state('menu.dairyGoat', {
    url: '/dairyGoat',
    views: {
      'side-menu21': {
        templateUrl: 'templates/dairyGoat.html',
        controller: 'dairyGoatCtrl'
      }
    }
  })

  .state('menu.reference', {
    url: '/reference',
    views: {
      'side-menu21': {
        templateUrl: 'templates/reference.html',
        controller: 'referenceCtrl'
      }
    }
  })

  .state('menu.diseaseDescription', {
    url: '/page13',
    views: {
      'side-menu21': {
        templateUrl: 'templates/diseaseDescription.html',
        controller: 'diseaseDescriptionCtrl'
      }
    }
  })

  .state('menu.diseaseDescription2', {
    url: '/page14',
    views: {
      'side-menu21': {
        templateUrl: 'templates/diseaseDescription2.html',
        controller: 'diseaseDescription2Ctrl'
      }
    }
  })

  .state('diseaseDescription3', {
    url: '/page15',
    templateUrl: 'templates/diseaseDescription3.html',
    controller: 'diseaseDescription3Ctrl'
  })

  .state('menu.diseaseDescription4', {
    url: '/page17',
    views: {
      'side-menu21': {
        templateUrl: 'templates/diseaseDescription4.html',
        controller: 'diseaseDescription4Ctrl'
      }
    }
  })

  .state('menu.diseaseDescription5', {
    url: '/page18',
    views: {
      'side-menu21': {
        templateUrl: 'templates/diseaseDescription5.html',
        controller: 'diseaseDescription5Ctrl'
      }
    }
  })

  .state('menu.diseaseDescription6', {
    url: '/page19',
    views: {
      'side-menu21': {
        templateUrl: 'templates/diseaseDescription6.html',
        controller: 'diseaseDescription6Ctrl'
      }
    }
  })

  .state('menu.diseaseDescription7', {
    url: '/page20',
    views: {
      'side-menu21': {
        templateUrl: 'templates/diseaseDescription7.html',
        controller: 'diseaseDescription7Ctrl'
      }
    }
  })

  .state('menu.diseaseDescription8', {
    url: '/page21',
    views: {
      'side-menu21': {
        templateUrl: 'templates/diseaseDescription8.html',
        controller: 'diseaseDescription8Ctrl'
      }
    }
  })

  .state('menu.diseaseDescription9', {
    url: '/page22',
    views: {
      'side-menu21': {
        templateUrl: 'templates/diseaseDescription9.html',
        controller: 'diseaseDescription9Ctrl'
      }
    }
  })

  .state('menu.diseaseDescription10', {
    url: '/page23',
    views: {
      'side-menu21': {
        templateUrl: 'templates/diseaseDescription10.html',
        controller: 'diseaseDescription10Ctrl'
      }
    }
  })

  .state('menu.breedingMethodDescription', {
    url: '/page9',
    views: {
      'side-menu21': {
        templateUrl: 'templates/breedingMethodDescription.html',
        controller: 'breedingMethodDescriptionCtrl'
      }
    }
  })

  .state('menu.breedingMethodDescription2', {
    url: '/page26',
    views: {
      'side-menu21': {
        templateUrl: 'templates/breedingMethodDescription2.html',
        controller: 'breedingMethodDescription2Ctrl'
      }
    }
  })

  .state('menu.breedingMethodDescription3', {
    url: '/page16',
    views: {
      'side-menu21': {
        templateUrl: 'templates/breedingMethodDescription3.html',
        controller: 'breedingMethodDescription3Ctrl'
      }
    }
  })

  .state('breedingMethodDescription4', {
    url: '/page27',
    templateUrl: 'templates/breedingMethodDescription4.html',
    controller: 'breedingMethodDescription4Ctrl'
  })

  .state('menu.dairyGoatDescription', {
    url: '/dairygoatdesc',
    views: {
      'side-menu21': {
        templateUrl: 'templates/dairyGoatDescription.html',
        controller: 'dairyGoatDescriptionCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/side-menu21/dairyGoat')


});